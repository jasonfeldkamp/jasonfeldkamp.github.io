clc
clear all
close all

figure(1)
axis square 
h = animatedline;

f = ones(1,10);
rad = zeros(1,2);
circles = gobjects(1,2);
lines = gobjects(1,2);

%circles(2) = drawCircle(rad1*cos(theta_initial),rad1*sin(theta_initial),rad2,'none','blue');
%lines(2) = line([rad1*cos(theta_initial),rad1*cos(theta_initial)+rad2*cos(theta_initial)], [rad1*sin(theta_initial),rad1*sin(theta_initial)+rad2*sin(theta_initial)], 'LineWidth', 2);

num_circles = 20;

subplot(1,2,1)
axis square
% Generate Graphics
xpos = 0;
for n = 1:num_circles
    f(n) = 2*n-1; % Square
    rad(n) = 1/(2*n-1); % Square
    %f(n) = n; % Sawtooth
    %rad(n) = 2/(n); % Sawtooth
    %f(n) = 4*n-1;
    %rad(n) = 1/(4*n-1);
    %f(n) = 2*n-3;
    %rad(n) = 1/(2*n-1);
    circles(n) = drawCircle(xpos, 0, rad(n), 'none', 'black');
    lines(n) = line([xpos, xpos+rad(n)], [0,0]);
    xpos = xpos + rad(n);
end

axis([-xpos,xpos,-xpos,xpos]);
height = zeros(1,2);
count = 1;

stepsize = 0.03;
thetamax = 6*pi;

subplot(1,2,2)
axis square
%axis([0, thetamax/stepsize, -3,3]) % square and sawtooth
%axis([0, thetamax/stepsize, -200,200]) % pulse
gr = animatedline;

for theta = 0:stepsize:thetamax
xpos = 0;
ypos = 0;
    for n = 1:num_circles
        set(circles(n), 'pos', [xpos - rad(n), ypos - rad(n), 2*rad(n), 2*rad(n)]);
        set(lines(n), 'XData', [xpos,xpos+rad(n)*cos(f(n)*theta)], 'YData', [ypos,ypos+rad(n)*sin(f(n)*theta)]);
        xpos = xpos + rad(n)*cos(f(n)*theta);
        ypos = ypos + rad(n)*sin(f(n)*theta);
        if n == num_circles
            addpoints(h,xpos,ypos);
            addpoints(gr, count, ypos)
            height(count) = ypos;
            count = count + 1;
        end
        pause(10^-8)
    end
end