function circle = drawCircle(x_center,y_center,r,c,color)
% Takes inputted center coordinates, radius, and color and draws a
% filled-in circle.
    % x_center is x coordinate of circle center
    % y_center is y coordinate of circle center
    % r is the radius of the circle
    % c is the color. Must be a valid MATLAB color string. (i.e. 'b')
    % Output is a figure with a desired circle drawn
    
% Error check function inputs
if r <= 0
    error('Error. The radius of the circle must be positive and nonzero.')
end

pos = [x_center - r, y_center - r,2*r,2*r]; 
% Define position vector for rectangle function
circle = rectangle('Position',pos,'Curvature', [1,1], 'FaceColor', c,'LineWidth',2,'EdgeColor',color); 
% Use rectangle function with [1,1] curvature to draw circle

