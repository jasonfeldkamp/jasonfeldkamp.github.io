classdef projectile
    properties
        position
        velocity
        acceleration
        graphic
        vector
        path
    end
    methods
        function projectile = projectile(position,velocity,acceleration)
            projectile.position = position;
            projectile.velocity = velocity;
            projectile.acceleration = acceleration;
            projectile.graphic = rectangle('Position', [position(1)-0.5,position(2)-0.5,1,1],'Curvature', [1,1], 'FaceColor','blue');
            projectile.vector = line([position(1),position(1) + sqrt(2)*velocity(1)/norm(velocity)],[position(2),position(2)+sqrt(2)*velocity(2)/norm(velocity)], 'Color', 'red', 'LineWidth', 2);
            projectile.path = animatedline;
        end
        function projectile = update(projectile,dt)
            projectile.velocity = projectile.velocity + projectile.acceleration*dt;
            projectile.position = projectile.position + projectile.velocity*dt;
            set(projectile.graphic, 'Position', [projectile.position(1)-0.5,projectile.position(2)-0.5,1,1]);
            set(projectile.vector, 'XData', [projectile.position(1),projectile.position(1)+sqrt(2)*projectile.velocity(1)/norm(projectile.velocity)],'YData',[projectile.position(2),projectile.position(2)+sqrt(2)*projectile.velocity(2)/norm(projectile.velocity)]);
            addpoints(projectile.path,projectile.position(1),projectile.position(2));
        end
    end
end