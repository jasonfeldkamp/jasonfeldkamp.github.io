% Created by Jason Feldkamp

clc
clear all
close all

figure(1)
axis equal
axis([0,50,0,40])
hold on

g = 9.8; % Constant gravity
dt = 0.005;

friendly = projectile([0,40],[0,50],[0,-2*g]); % Friendly starts at rest
enemy = projectile([0,0],[40,25],[0,-4*g]); % Enemy starts with initial velocity

max_deflect = 0.5;

enemy_log = zeros(1,2);
dir_log = zeros(1,2);
dir_log(3,:) = [0,1];
k = 1;
finalt = 10;

for t = 0:dt:finalt
    enemy_log(k,1) = enemy.position(1);
    enemy_log(k,2) = enemy.position(2);
    if k > 3% && k < 30
        dir_log(k,:) = smartRead(enemy_log,friendly,dt,k);
        %if 180 - abs(abs(atand(dir_log(k,2)/dir_log(k,1))-atand(dir_log(k-1,2)/dir_log(k-1,1))) - 180) > max_deflect % If change in direction exceeds max_deflect
            %dir_log(k,:) = rotate(dir_log(k-1,:),dir_log(k,:),max_deflect);
        %end
        friendly.velocity = norm(friendly.velocity)*dir_log(k,:);
    %else
        %friendly.velocity = norm(friendly.velocity)*dumbRead(friendly.position,enemy.position);
       %pause(10^-1)
    end
    friendly = update(friendly,dt);
    enemy = update(enemy,dt);
    pause(10^-10)
    k = k + 1;
end

function dir = dumbRead(current_pos, enemy_pos)
    dir = (enemy_pos - current_pos)/norm(enemy_pos - current_pos); % direction enemy is traveling
end

function v_rot = rotate(v1,v2,theta)
% Rotate v1 towards v2 by angle theta (in degrees)
% Works for both 2D and 3D vectors
    if length(v1) == 2 && length(v2) == 2
        axis = -1*cross([v1(1),v1(2),0],[v2(1),v2(2),0]);
        v_rot_prime = [v1(1),v1(2),0]*cosd(theta)+axis*(dot(axis,[v1(1),v1(2),0]))*(1-cosd(theta))+cross([v1(1),v1(2),0],axis)*sind(theta);
        v_rot = [v_rot_prime(1),v_rot_prime(2)];
    elseif length(v1) == 3 && length(v2) == 3
        axis = cross(v1,v2);
        v_rot = v1*cosd(theta)+axis*(dot(axis,v1))*(1-cosd(theta))+cross(v1,axis)*sind(theta);
    else
        error('v1 and v2 must be 2D or 3D, and must have matching dimension.')
    end
end

function dir = smartRead(enemy_positions,obj_friend,dt,k)
    enemy_v1(1) = (enemy_positions(k,1) - enemy_positions(k-1,1))/dt;
    enemy_v1(2) = (enemy_positions(k,2) - enemy_positions(k-1,2))/dt;
    enemy_v2(1) = (enemy_positions(k-1,1) - enemy_positions(k-2,1))/dt;
    enemy_v2(2) = (enemy_positions(k-1,2) - enemy_positions(k-2,2))/dt;
    enemy_a = (enemy_v1-enemy_v2)/dt;
    % Predicting flight path
    x_predict(1,1) = enemy_positions(k,1);
    x_predict(1,2) = enemy_positions(k,2);
    v_predict(1,1) = enemy_v1(1);
    v_predict(1,2) = enemy_v1(2);
    j = 1;
    while j < 200 %x_predict(j,2) >= 0
        % Linear v prediction
        v_predict(j+1,1) = v_predict(j,1) + enemy_a(1)*dt;
        v_predict(j+1,2) = v_predict(j,2) + enemy_a(2)*dt;
        % Euler method x prediction
        x_predict(j+1,1) = x_predict(j,1) + v_predict(j,1)*dt;
        x_predict(j+1,2) = x_predict(j,2) + v_predict(j,2)*dt;
        j = j+1;
    end
    % Sifting for best trajectory
    predicts = zeros(1,2);
    errors = zeros(1,2);
    for l = 1:length(x_predict)
        v_cur = norm(obj_friend.velocity);
        x_cur = obj_friend.position;
        t = 0;
        while (norm(x_cur-obj_friend.position) < norm(x_predict(l,:)-obj_friend.position))
            v_cur = norm(v_cur)*(x_predict(l,:)-obj_friend.position)/norm((x_predict(l,:)-obj_friend.position)) + obj_friend.acceleration*dt;
            x_cur = x_cur + v_cur*dt;
            t = t + dt;
        end
        predicts(l) = t;
        errors(l) = sqrt(predicts(l)^2 - (l*dt)^2);
    end
    [no,index] = min(errors);
    %figure(2)
    %plot(predicts)
    dir = (x_predict(index,:)-obj_friend.position)/norm((x_predict(index,:)-obj_friend.position));
end