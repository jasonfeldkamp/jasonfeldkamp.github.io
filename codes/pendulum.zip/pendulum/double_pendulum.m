% Created by Jason Feldkamp

clc
clear all
close all

% Constants
l1 = 1;
l2 = 1;
g = 9.81;
m1 = 1;
m2 = 1;

% Initialize theta matrix: theta1(1), theta2(2), vel1(3), vel2(4), acc1(5),
% acc2(6), t(7), x1(8), y1(9), x2(10), y2(11)
theta = zeros(11,2);

% Initial Conditions
theta(1,1) = pi/3;
theta(2,1) = -pi/2;
theta(3,1) = -1;
theta(4,1) = 3;

% Define time constraints
dt = 0.005;
final_t = 500;

% Define index counter
step = 1;

damp = 1-2*10^-4;

% Numerically solve differential equation (time domain)
for t = 0:dt:final_t
    theta(7,step) = t;
    theta(8,step) = l1*sin(theta(1,step));
    theta(9,step) = -l1*cos(theta(1,step));
    theta(10,step) = theta(8,step) + l2*sin(theta(2,step));
    theta(11,step) = theta(9,step) - l2*cos(theta(2,step));
    d = theta(1,step) - theta(2,step);
    %theta(5,step) = (m2*l1*theta(3,step)^2*sin(d)*cos(d)+m2*g*sin(theta(2,step))*cos(d)+m2*l2*theta(4,step)^2*sin(d)-(m1+m2)*g*sin(theta(1,step)))/((m1+m2)*l1-m2*l1*(cos(d))^2);
    %theta(6,step) = (-m2*l2*theta(4,step)^2*sin(d)*cos(d)+(m1+m2)*(g*sin(theta(1,step))*cos(d)-l1*theta(3,step)^2*sin(d)-g*sin(theta(2,step))))/((m1+m2)*l2-m2*l2*(cos(d))^2);
    
    t1 = theta(1,step);
    t2 = theta(2,step);
    v1 = theta(3,step);
    v2 = theta(4,step);
    
    theta(5,step) = (-m2*cos(d)*l1*v1^2*sin(d)+m2*cos(d)*g*sin(t2)-m2*l2*v2^2*sin(d)-(m1+m2)*g*sin(t1))/(l1*(m1+m2-m2*(cos(d))^2));
    theta(6,step) = ((m1+m2)*(l1*v1^2*sin(d)+((v2^2*sin(d)*cos(d)*m2*l2)/(m1+m2))+cos(d)*g*sin(t1)-g*sin(t2)))/(l2*(m1+m2*(sin(d))^2));
    
    theta(3,step+1) = (theta(3,step) + theta(5,step)*dt)*damp;
    theta(4,step+1) = (theta(4,step) + theta(6,step)*dt)*damp;
    theta(1,step+1) = theta(1,step) + theta(3,step)*dt;
    theta(2,step+1) = theta(2,step) + theta(4,step)*dt;
    theta(12,step) = 0.5*m1*theta(3,step)^2;
    theta(13,step) = 0.5*m2*theta(4,step)^2;
    theta(14,step) = m1*g*(theta(9,step)+l1);
    theta(15,step) = m2*g*(theta(11,step)+l1+l2);
    theta(16,step) = theta(12,step) + theta(13,step) + theta(14,step) + theta(15,step);
    step = step + 1;
end

step = 1;

figure(1)
h = animatedline;
%h.LineWidth = 1;
axis([-2.2,2.2,-2.2,2.2])
axis square
hold on

bob1 = drawCircle(theta(8,step),theta(9,step), 0.03,'b','b');
bob2 = drawCircle(theta(8,step),theta(9,step), 0.03,'b','b');
line1 = line([0,theta(8,step)],[0,theta(9,step)],'color','b');
line2 = line([theta(8,step),theta(10,step)],[theta(9,step),theta(11,step)],'color','b');                       
origin = drawCircle(0,0,0.01,'black','black');

%vidfile = VideoWriter('trial3.mp4','MPEG-4'); % Generate video file
%vidfile.FrameRate = 60; % Set frame rate
%open(vidfile); % Open file for recording

for t = 0:dt:final_t
    set(bob1, 'Position', [theta(8,step)-0.03,theta(9,step)-0.03,2*0.03,2*0.03]);
    set(bob2, 'Position', [theta(10,step)-0.03,theta(11,step)-0.03,2*0.03,2*0.03]);
    set(line1, 'XData', [0,theta(8,step)], 'YData', [0,theta(9,step)]);
    set(line2, 'XData', [theta(8,step),theta(10,step)], 'YData', [theta(9,step),theta(11,step)]);
    addpoints(h,theta(10,step),theta(11,step));
    pause(10^-10)
    step = step + 1;
    %frame = getframe(gcf); % Get frame
    %writeVideo(vidfile,frame); % Write video with frame
end

delete(bob1)
delete(bob2)
delete(line1)
delete(line2)
delete(origin)

%close(vidfile); % Close video file

figure(2)
plot(theta(7,:),theta(16,:))

figure(3)
plot(theta(2,:),theta(4,:))

fprintf('Simulation complete.')
